<?php
include '../database/config.php';

if(isset($_GET['id']))
{


  $id=$_GET['id'];
  $sql="select * from paper where id='$id'";

  $result=mysqli_query($conn,$sql);

  $row=mysqli_fetch_array($result);
  $extension='../database/';
  
  $name=$row['course_name'];
  $image=$extension.$row['course_image'];


  header('Content-type: application/force-download');
  header('Content-disposition: attachment; filename="'.basename($image).'"');
  header('Content-length: '.filesize( $image ));
  readfile($image);
  


}


?>
